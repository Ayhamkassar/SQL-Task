﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=AYHAM;database=Resturant;Integrated Security=True";
            string insertQuery = "INSERT INTO Foods (MealNumber,MealName,Price,Copon)Values(@mealNumber,@mealName,@Price,@Copon)";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@mealNumber", textBox1.Text);
                        insertCommand.Parameters.AddWithValue("@mealName", textBox2.Text); 
                        insertCommand.Parameters.AddWithValue("@Price", textBox3.Text); 
                        insertCommand.Parameters.AddWithValue("@Copon", textBox4.Text); 

                        insertCommand.ExecuteNonQuery();
                        MessageBox.Show("تم إضافة البيانات بنجاح");
                    }


                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string selectQuery = "SELECT * FROM Foods";
            string connectionString = "Data Source=AYHAM;database=Resturant;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(selectCommand))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;
                    }
                }
                connection.Close();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=AYHAM;database=Resturant;Integrated Security=True";
            string deleteQuery = "DELETE FROM Foods where MealNumber = " + textBox1.Text;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand insertCommand = new SqlCommand(deleteQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@mealNumber", textBox1.Text);

                        insertCommand.ExecuteNonQuery();
                        MessageBox.Show("تم الحذف بنجاح");
                    }

                    
                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=AYHAM;database=Resturant;Integrated Security=True";
            string updateQuery = "UPDATE Foods SET MealName = @mealName WHERE MealNumber = @mealNumber";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.Add("@mealNumber", SqlDbType.Int).Value = int.Parse(textBox1.Text);
                        updateCommand.Parameters.Add("@mealName", SqlDbType.NVarChar).Value = textBox2.Text;

                        updateCommand.ExecuteNonQuery();
                        MessageBox.Show("تم التحديث بنجاح");
                    }


                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }

            }
        }
    }
}

